<?php
/**
 *
 * Display the page meta box.
 *
 * @author      MadrasThemes
 * @category    Admin
 * @package     around/Admin/MetaBoxes
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists( 'Around_Meta_Box_Cover_Image' ) ) {
    /**
     * Around_Meta_Box_Cover_Image Class.
     */
    class Around_Meta_Box_Cover_Image {
        /**
         * Render Meta Box content.
         *
         * @param WP_Post $post The post object.
         */
        public static function output( $post ) {

            $clean_meta_data = get_post_meta( $post->ID, '_ar_cover_image', true );
            $ar_cover_image  = maybe_unserialize( $clean_meta_data );

            wp_nonce_field( 'around_save_data', 'around_meta_nonce' );

            ?><div class="around-options"><?php

                around_wp_upload_image( array(
                    'id'            => '_ar_cover_image',
                    'name'          => '_ar_cover_image',
                    'label'         => esc_html__( 'Cover Image', 'around-extensions' ),
                    'placeholder'   => true,
                    'value'         => isset( $ar_cover_image ) ? $ar_cover_image : '',

                ) );

            ?></div><?php
        }

        public static function save( $post_id, $post ) {
            if ( isset( $_POST['_ar_cover_image'] ) ) {
                $clean_ar_cover_image = around_clean( $_POST['_ar_cover_image'] );
                update_post_meta( $post_id, '_ar_cover_image',  serialize( $clean_ar_cover_image ) );
            }   
        }
    }
}
