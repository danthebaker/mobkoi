<?php
/**
 * Around Admin
 *
 * @class    Around_Admin
 * @author   MadrasThemes
 * @category Admin
 * @package  AroundExtensions/Admin
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Around_Admin class.
 */
class Around_Admin {

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'init', array( $this, 'includes' ) );
        add_action( 'admin_init', array( $this, 'buffer' ), 1 );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

    }

    /**
     * Output buffering allows admin screens to make redirects later on.
     */
    public function buffer() {
        ob_start();
    }

    /**
     * Include any classes we need within admin.
     */
    public function includes() {
        include_once dirname( __FILE__ ) . '/around-meta-box-functions.php';
        include_once dirname( __FILE__ ) . '/class-around-admin-meta-boxes.php';
    }

    /**
     * Enqueue style.
     */
    public function admin_styles() {
        $version = Around_Extensions()->version;
        wp_register_style( 'around-admin-meta-boxes', plugins_url( '/assets/css/admin-meta-boxes.css', AROUND_PLUGIN_FILE ), array(), $version );
        wp_enqueue_style( 'around-admin-meta-boxes' );

    }

    /**
     * Enqueue scripts.
     */
    public function admin_scripts() {
        $version = Around_Extensions()->version;
        wp_register_script( 'around-admin-meta-boxes', plugins_url( '/assets/js/admin-meta-boxes.js', AROUND_PLUGIN_FILE ), array( 'jquery', 'jquery-ui-datepicker', 'jquery-ui-sortable'), $version );
        wp_enqueue_script( 'around-admin-meta-boxes' );
    }

    /**
     * Include admin files conditionally.
     */
    public function conditional_includes() {
        if ( ! $screen = get_current_screen() ) {
            return;
        }
    }
}

return new Around_Admin();
