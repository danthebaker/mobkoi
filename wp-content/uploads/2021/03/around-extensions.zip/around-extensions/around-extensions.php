<?php
/**
 * Plugin Name:     Around Extensions
 * Plugin URI:      https://themeforest.net/user/madrasthemes/portfolio
 * Description:     This selection of extensions compliment our theme Around. Please note: they don’t work with any WordPress theme, just Around.
 * Author:          MadrasThemes
 * Author URI:      https://madrasthemes.com/
 * Version:         0.1.3
 * Text Domain:     around-extensions
 * Domain Path:     /languages
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define AROUND_PLUGIN_FILE.
if ( ! defined( 'AROUND_PLUGIN_FILE' ) ) {
    define( 'AROUND_PLUGIN_FILE', __FILE__ );
}

if( ! class_exists( 'Around_Extensions' ) ) {
    /**
     * Main Around_Extensions Class
     *
     * @class Around_Extensions
     * @version 1.0.0
     * @since 1.0.0
     * @package Around
     * @author MadrasThemes
     */
    final class Around_Extensions {

        /**
         * Around_Extensions The single instance of Around_Extensions.
         * @var     object
         * @access  private
         * @since   1.0.0
         */
        private static $_instance = null;

        /**
         * The token.
         * @var     string
         * @access  public
         * @since   1.0.0
         */
        public $token;

        /**
         * The version number.
         * @var     string
         * @access  public
         * @since   1.0.0
         */
        public $version;

        /**
         * Constructor function.
         * @access  public
         * @since   1.0.0
         * @return  void
         */
        public function __construct () {

            $this->token    = 'around-extensions';
            $this->version  = '1.0.0';

            add_action( 'plugins_loaded', array( $this, 'setup_constants' ), 10 );
            add_action( 'plugins_loaded', array( $this, 'includes' ),        20 );
        }

        /**
         * Main Around_Extensions Instance
         *
         * Ensures only one instance of Around_Extensions is loaded or can be loaded.
         *
         * @since 1.0.0
         * @static
         * @see Around_Extensions()
         * @return Main Around instance
         */
        public static function instance () {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        /**
         * Setup plugin constants
         *
         * @access public
         * @since  1.0.0
         * @return void
         */
        public function setup_constants() {

            // Plugin Folder Path
            if ( ! defined( 'AROUND_EXTENSIONS_DIR' ) ) {
                define( 'AROUND_EXTENSIONS_DIR', plugin_dir_path( __FILE__ ) );
            }

            // Plugin Folder URL
            if ( ! defined( 'AROUND_EXTENSIONS_URL' ) ) {
                define( 'AROUND_EXTENSIONS_URL', plugin_dir_url( __FILE__ ) );
            }

            // Plugin Root File
            if ( ! defined( 'AROUND_EXTENSIONS_FILE' ) ) {
                define( 'AROUND_EXTENSIONS_FILE', __FILE__ );
            }

            // Modules File
            if ( ! defined( 'AROUND_EXTENSIONS_MODULES_DIR' ) ) {
                define( 'AROUND_EXTENSIONS_MODULES_DIR', AROUND_EXTENSIONS_DIR . '/modules' );
            }

            $this->define( 'AROUND_ABSPATH', dirname( AROUND_EXTENSIONS_FILE ) . '/' );
            $this->define( 'AROUND_VERSION', $this->version );
        }

        /**
         * Define constant if not already set.
         *
         * @param string      $name  Constant name.
         * @param string|bool $value Constant value.
         */
        private function define( $name, $value ) {
            if ( ! defined( $name ) ) {
                define( $name, $value );
            }
        }

        /**
         * What type of request is this?
         *
         * @param  string $type admin, ajax, cron or aroundend.
         * @return bool
         */
        private function is_request( $type ) {
            switch ( $type ) {
                case 'admin':
                    return is_admin();
                case 'ajax':
                    return defined( 'DOING_AJAX' );
                case 'cron':
                    return defined( 'DOING_CRON' );
                case 'aroundend':
                    return ( ! is_admin() || defined( 'DOING_AJAX' ) ) && ! defined( 'DOING_CRON' ) && ! $this->is_rest_api_request();
            }
        }

        /**
         * Include required files
         *
         * @access public
         * @since  1.0.0
         * @return void
         */
        public function includes() {
            /**
             * Class autoloader.
             */
            include_once AROUND_EXTENSIONS_DIR . '/includes/class-around-autoloader.php';

            /**
             * Core classes.
             */
           require AROUND_EXTENSIONS_DIR . '/includes/functions.php';
           //require AROUND_EXTENSIONS_DIR . '/includes/around-core-functions.php';

            // /**
            //  * WP Job Manger.
            //  */
            // require_once AROUND_EXTENSIONS_DIR . '/includes/custom-post-types/jobs.php';

            /**
             * Custom Post Types
             */
           require AROUND_EXTENSIONS_MODULES_DIR . '/portfolio/classes/class-around-jetpack-portfolio.php';

            if ( $this->is_request( 'admin' ) ) {
                include_once AROUND_EXTENSIONS_DIR . '/includes/admin/class-around-admin.php';
            }

            /**
             * Social Share
             *
             */
            require AROUND_EXTENSIONS_MODULES_DIR . '/social-share/class-around-socialshare.php';
        }

        /**
         * Get the plugin url.
         *
         * @return string
         */
        public function plugin_url() {
            return untrailingslashit( plugins_url( '/', AROUND_PLUGIN_FILE ) );
        }

        /**
         * Cloning is forbidden.
         *
         * @since 1.0.0
         */
        public function __clone () {
            _doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'around-extensions' ), '1.0.0' );
        }

        /**
         * Unserializing instances of this class is forbidden.
         *
         * @since 1.0.0
         */
        public function __wakeup () {
            _doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'around-extensions' ), '1.0.0' );
        }
    }
}

/**
 * Returns the main instance of Around_Extensions to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object Around_Extensions
 */
function Around_Extensions() {
    return Around_Extensions::instance();
}

/**
 * Initialise the plugin
 */
Around_Extensions();
