<?php

// Static Content Jetpack Share Remove
if ( ! function_exists( 'around_mas_static_content_jetpack_sharing_remove_filters' ) ) {
    function around_mas_static_content_jetpack_sharing_remove_filters() {
        if( function_exists( 'sharing_display' ) ) {
            remove_filter( 'the_content', 'sharing_display', 19 );
        }
    }
}

add_action( 'mas_static_content_before_shortcode_content', 'around_mas_static_content_jetpack_sharing_remove_filters' );

if ( ! function_exists( 'around_mas_static_content_jetpack_sharing_add_filters' ) ) {
    function around_mas_static_content_jetpack_sharing_add_filters() {
        if( function_exists( 'sharing_display' ) ) {
            add_filter( 'the_content', 'sharing_display', 19 );
        }
    }
}

add_action( 'mas_static_content_after_shortcode_content', 'around_mas_static_content_jetpack_sharing_add_filters' );

// Jetpack
if ( ! function_exists( 'around_jetpack_sharing_remove_filters' ) ) {
    function around_jetpack_sharing_remove_filters() {
        if( function_exists( 'sharing_display' ) ) {
            remove_filter( 'the_content', 'sharing_display', 19 );
            remove_filter( 'the_excerpt', 'sharing_display', 19 );
        }
    }
}

add_action( 'around_single_post_before', 'around_jetpack_sharing_remove_filters', 5 );
add_action( 'woocommerce_after_single_product_summary', 'around_jetpack_sharing_remove_filters', 5 );



// Register widgets.
if ( ! function_exists ( 'around_widgets_register' )  ) {

    function around_widgets_register() {

        if ( class_exists( 'Around' ) ) {
            include_once AROUND_EXTENSIONS_DIR . '/includes/widgets/class-around-random-posts-widget.php';
            register_widget( 'Around_Random_Posts_Widget' );
        }
    }
}

add_action( 'widgets_init', 'around_widgets_register' );
