<?php
/**
 * Docs Icons
 *
 * Display the docs meta box.
 *
 * @author      MadrasThemes
 * @category    Admin
 * @package     Around/Admin/Meta Boxes
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Around_Meta_Box_Docs Class.
 */
class Around_Meta_Box_Docs {

    /**
     * Output the metabox.
     *
     * @param WP_Post $post
     */
    public static function output( $post ) {
        global $thepostid;
        $thepostid      = $post->ID;

        wp_nonce_field( 'around_save_data', 'around_meta_nonce' );

        self::output_docs( $post );
    }

    private static function output_docs( $post ) {

        if ( ! function_exists( 'around_get_docs_meta' ) ) {
            return;
        }

        $wedocs = around_get_docs_meta();

        ?><div class="around-options"><?php

            around_wp_text_input( array(
                'id'            => '_wedocs_post_featured_icon',
                'name'          => '_wedocs[post_featured_icon]',
                'label'         => esc_html__( 'Featured Icon', 'around-extensions' ),
                'value'         => isset( $wedocs['post_featured_icon'] ) ? $wedocs['post_featured_icon'] : '',
            ) );

            around_wp_select( array(
                'label'         => esc_html__( 'Featured Icon Background', 'around-extensions' ),
                'name'          => '_wedocs[post_featured_icon_bg]',
                'id'            => '_wedocs_post_featured_icon_bg',
                'type'          => 'select',
                'options'       => array(
                    'primary'       => esc_html__( 'Primary', 'around-extensions'),
                    'secondary'     => esc_html__( 'Secondary', 'around-extensions'), 
                    'success'       => esc_html__( 'Success', 'around-extensions'),
                    'danger'        => esc_html__( 'Danger', 'around-extensions'),
                    'warning'       => esc_html__( 'Warning', 'around-extensions'),
                    'info'          => esc_html__( 'Info', 'around-extensions'),
                    'light'         => esc_html__( 'Light', 'around-extensions'),
                    'dark'          => esc_html__( 'Dark', 'around-extensions'),
                    'primary-desat' => esc_html__( 'Primary Desat', 'around-extensions'),
                ),
                'value'         => isset( $wedocs['post_featured_icon_bg'] ) ? $wedocs['post_featured_icon_bg'] : '',
            ) );

        ?></div><?php
    }
    

    /**
     * Save meta box data.
     *
     * @param int     $post_id
     * @param WP_Post $post
     */


    public static function save( $post_id, $post ) {
        if ( isset( $_POST['_wedocs'] ) ) {
            $clean_docs_options = around_clean( $_POST['_wedocs'] );
            update_post_meta( $post_id, '_docs_options',  serialize( $clean_docs_options ) );
        }   
    }
}
