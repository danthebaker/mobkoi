jQuery( function ( $ ) {
	// Select Change Media
	$( '.show_hide_select' ).on( 'change', function() {
		
		var field_select = $(this).val(), 
			select_id = $(this).attr('id'),
			$ar_selelct_option_group = $(this).parents( '.options_group' );

		$ar_selelct_option_group.find( '.hide_if_' + select_id ).hide();
		$ar_selelct_option_group.find( '.show_if_' + select_id + '_' + field_select ).show();
	} ).change();

	// Checkbox Change Media
	$( '.show_hide_checkbox' ).on( 'change', function() {
		
		var field_checked = $(this).is(":checked"),
			check_box_id = $(this).attr('id'),
			$ar_checkbox_option_group = $(this).parents( '.options_group' );

		$ar_checkbox_option_group.find( '.hide_if_' + check_box_id ).hide();

		if( field_checked ) {
			$ar_checkbox_option_group.find( '.show_if_' + check_box_id + '_yes' ).show();
		} else {
			$ar_checkbox_option_group.find( '.show_if_' + check_box_id + '_no' ).show();
		}
	} ).change();

	// Uploading Media
	if ( ! $('.upload_image_id').val() ) {
		$('.ar_remove_image_button').hide();
	}

	$(document).on( 'click', '.ar_upload_image_button', function( event ){
		var $this = $(this);
		var current_block = $(this).parent('.form-field').attr('id');

		if( typeof file_frame == 'undefined' ) {
			var file_frame;
		}

		event.preventDefault();

		// If the media frame already exists, reopen it.
		if ( file_frame ) {
			file_frame.open();
			return;
		}

		// Create the media frame.
		file_frame = wp.media.frames.downloadable_file = wp.media({
			title: 'Choose an image',
			button: {
				text: 'Use image',
			},
			multiple: false
		});

		// When an image is selected, run a callback.
		file_frame.on( 'select', function() {
			attachment = file_frame.state().get('selection').first().toJSON();

			$('#'+current_block+' .upload_image_id').val( attachment.id );
			$('#'+current_block+' img.upload_image_preview').attr('src', attachment.url );
			$('#'+current_block+' .ar_remove_image_button').show();
			$this.closest( '.widget-inside' ).find( '.widget-control-save' ).prop( 'disabled', false );
		});

		// Finally, open the modal.
		file_frame.open();
	});

	$(document).on( 'click', '.ar_remove_image_button', function( event ){
		var $this = $(this);
		var current_block = $(this).parent('.form-field').attr('id');

		$('#'+current_block+' img.upload_image_preview').attr('src', $('#'+current_block+' img.upload_image_preview').data('placeholder-src'));
		$('#'+current_block+' .upload_image_id').val('');
		$('#'+current_block+' .ar_remove_image_button').hide();
		$this.closest( '.widget-inside' ).find( '.widget-control-save' ).prop( 'disabled', false );

		return false;
	});
});